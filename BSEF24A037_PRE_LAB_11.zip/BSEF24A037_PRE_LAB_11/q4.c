//#include <stdio.h>
//
//int main() {
//    int i, j, rows, cols;
//    int matrix[10][10];
//     
//    printf("Enter rows and columns: ");
//    scanf_s("%d %d", &rows, &cols);
//     
//    printf("Enter matrix elements:\n");
//    for (i = 0; i < rows; i++) {
//        for (j = 0; j < cols; j++) {
//            scanf_s("%d", &matrix[i][j]);
//        }
//    } 
//
//    for (i = 0; i < rows; i++) {
//        for (j = 0; j < cols / 2; j++) {
//            int temp = matrix[i][j];
//            matrix[i][j] = matrix[i][cols - 1 - j];
//            matrix[i][cols - 1 - j] = temp;
//        }
//    }
//     
//    printf("Matrix after reversing each row:\n");
//    for (i = 0; i < rows; i++) {
//        for (j = 0; j < cols; j++) {
//            printf("%d ", matrix[i][j]);
//        }
//        printf("\n");
//    }
//
//    return 0;
//}
