//#include <stdio.h>
//
//int main()
//{
//    int omrSheet[5][4];
//    int i, j, sum;
//    int isValid = 1;  
//
//    printf("Enter the 5x4 OMR sheet (only 0 or 1):\n");
//    for (i = 0; i < 5; i++) {
//        for (j = 0; j < 4; j++) {
//            scanf_s("%d", &omrSheet[i][j]);
//        }
//    }
//     
//    for (i = 0; i < 5; i++) {
//        sum = 0;
//        for (j = 0; j < 4; j++) {
//            sum += omrSheet[i][j];
//        }
//         
//        if (sum != 1) {
//            isValid = 0;
//            break;
//        }
//    }
//
//    if (isValid)
//        printf("Result: Valid OMR Sheet\n");
//    else
//        printf("Result: Invalid OMR Sheet\n");
//
//    return 0;
//}
